def safe_call(args, shell=False):
    # discard shell
    
