# Find the initial estimates of the parameters
# by Anton Korobeynikov

source("est-mean.r", chdir=T)

est.params <- function(d) {
  # First, find the valley and first coverage maximum using the smoothed histogram
  v <- est.mean(d)
  max.cov <- v[1]
  valley <- v[2]

  # Now find the median coverage value for everything past the valley
  vals <- d[,2]
  cvals <- cumsum(vals[(valley+1):length(vals)])
  before_median <- c(0,which(cvals < cvals[length(cvals)] / 2))
  mcov <- valley + max(before_median)

  # The new estimate of the mean coverage is the max of two estimates
  max.cov <- max(mcov, max.cov)

  # Try to estimate the deviation calculating the median absolute difference wrt
  # the calculated max.cov
  mvals <- c(vals[max.cov], vals[(max.cov+1):(2*max.cov-valley-1)] + rev(vals[(valley+1):(max.cov - 1)]))
  cvals <- cumsum(mvals)
  before_median <- c(0,which(cvals < cvals[length(cvals)] / 2))
  cov.sd <- 1.4826 * max(before_median - 1)
  cov.sd <- max(cov.sd,1.4826) # appears needed, sd=0 provokes crash in EMOpt

  # The initial estimate of erroroneous probability is just the ratio of k-mers
  # before the valley
  p.err <- sum(as.numeric(vals[1:valley])) / sum(as.numeric(vals))

  # FIXME: Estimate the skewness for skew normal
  # gamma <- min(0.9, abs(<sample skew>))
  # delta <- sqrt(pi / 2 * (gamma ^ (2/3)) / (gamma ^ (2/3) + ((4 - pi)/2) ^ (2/3)))
  # shape <- sign(<sample skew>) * delta / sqrt(1 - delta ^2)
  shape <- 0
  c(max.cov, cov.sd, p.err, shape)
}

